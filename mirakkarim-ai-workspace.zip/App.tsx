
import React, { useState, useEffect, useRef } from 'react';
import { AppState, ChatSession, Message, ModelType, GenerationMode, Attachment } from './types';
import { Icons, DEFAULT_SYSTEM_INSTRUCTION } from './constants';
import { sendMessageToGemini, generateVideoWithMirakkarim } from './services/gemini';
import ChatMessage from './components/ChatMessage';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('mirakkarim-v2-chats');
    const initialChats = saved ? JSON.parse(saved) : [];
    return {
      chats: initialChats,
      activeChatId: initialChats.length > 0 ? initialChats[0].id : null,
      isSidebarOpen: window.innerWidth > 1024,
    };
  });

  const [input, setInput] = useState('');
  const [chatSearchTerm, setChatSearchTerm] = useState('');
  const [msgSearchTerm, setMsgSearchTerm] = useState('');
  const [isMsgSearchOpen, setIsMsgSearchOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [videoStatus, setVideoStatus] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showSubscription, setShowSubscription] = useState(false);
  const [userName, setUserName] = useState(() => localStorage.getItem('mirakkarim-user-name') || 'Пользователь');
  const [isSubscribed, setIsSubscribed] = useState(() => localStorage.getItem('mirakkarim-subscribed') === 'true');
  const [error, setError] = useState<string | null>(null);
  const [pendingAttachments, setPendingAttachments] = useState<Attachment[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    localStorage.setItem('mirakkarim-v2-chats', JSON.stringify(state.chats));
    localStorage.setItem('mirakkarim-user-name', userName);
    localStorage.setItem('mirakkarim-subscribed', String(isSubscribed));
  }, [state.chats, userName, isSubscribed]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.chats, state.activeChatId, isTyping, videoStatus]);

  const activeChat = state.chats.find(c => c.id === state.activeChatId);

  const filteredChats = state.chats.filter(chat => 
    chat.title.toLowerCase().includes(chatSearchTerm.toLowerCase())
  );

  const filteredMessages = activeChat 
    ? activeChat.messages.filter(msg => 
        msg.content.toLowerCase().includes(msgSearchTerm.toLowerCase())
      )
    : [];

  const createNewChat = () => {
    const newChat: ChatSession = {
      id: crypto.randomUUID(),
      title: 'Новый диалог',
      model: 'mirakkarim-3-pro',
      mode: 'auto',
      systemInstruction: DEFAULT_SYSTEM_INSTRUCTION,
      messages: [],
      createdAt: Date.now(),
    };
    setState(prev => ({
      ...prev,
      chats: [newChat, ...prev.chats],
      activeChatId: newChat.id,
      isSidebarOpen: window.innerWidth > 768 ? prev.isSidebarOpen : false,
    }));
  };

  const deleteChat = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setState(prev => {
      const newChats = prev.chats.filter(c => c.id !== id);
      const newActiveId = prev.activeChatId === id ? (newChats.length > 0 ? newChats[0].id : null) : prev.activeChatId;
      return { ...prev, chats: newChats, activeChatId: newActiveId };
    });
  };

  const updateActiveChat = (updates: Partial<ChatSession>) => {
    if (!state.activeChatId) return;
    setState(prev => ({
      ...prev,
      chats: prev.chats.map(c => c.id === state.activeChatId ? { ...c, ...updates } : c)
    }));
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newAtts: Attachment[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      const base64Promise = new Promise<string>((resolve) => {
        reader.onload = () => {
          const base64 = (reader.result as string).split(',')[1];
          resolve(base64);
        };
      });
      reader.readAsDataURL(file);
      const data = await base64Promise;
      newAtts.push({
        data,
        mimeType: file.type || 'application/octet-stream',
        name: file.name
      });
    }
    setPendingAttachments(prev => [...prev, ...newAtts]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removePendingAttachment = (idx: number) => {
    setPendingAttachments(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSubscribe = (plan: string, price: string) => {
    setIsSubscribed(true);
    localStorage.setItem('mirakkarim-subscribed', 'true');
    setShowSubscription(false);
    alert(`План ${plan} (${price}) успешно активирован!`);
  };

  const handleSend = async () => {
    if (!activeChat || isTyping) return;
    if (input.trim() === '' && pendingAttachments.length === 0) return;

    setError(null);
    
    const userMsg: Message = { 
      id: crypto.randomUUID(), 
      role: 'user', 
      content: input, 
      attachments: pendingAttachments.length > 0 ? pendingAttachments : undefined,
      timestamp: Date.now() 
    };
    
    const updatedHistory = [...activeChat.messages, userMsg];
    updateActiveChat({ 
      messages: updatedHistory,
      title: activeChat.messages.length === 0 ? (input.length > 30 ? input.slice(0, 30) + '...' : input) : activeChat.title 
    });
    
    const currentInput = input;
    const currentAttachments = pendingAttachments;
    const currentModel = activeChat.model;
    const currentMode = activeChat.mode;

    setInput('');
    setPendingAttachments([]);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    setIsTyping(true);

    try {
      if (currentModel === 'mirakkarim-video-ultra') {
        const aiStudio = (window as any).aistudio;
        if (aiStudio) {
          const hasKey = await aiStudio.hasSelectedApiKey();
          if (!hasKey) {
            const confirm = window.confirm("Для генерации видео Veo требуется платный API-ключ. Открыть Mirakkarim Key Manager?");
            if (confirm) {
              await aiStudio.openSelectKey();
            }
            setIsTyping(false);
            return;
          }
        }

        setVideoStatus("Инициализация квантового видео-ядра...");
        const videoAtt = await generateVideoWithMirakkarim(currentInput, setVideoStatus);
        const modelMsg: Message = { 
          id: crypto.randomUUID(), 
          role: 'model', 
          content: "Видео успешно синтезировано по вашему запросу.", 
          attachments: [videoAtt],
          timestamp: Date.now() 
        };
        updateActiveChat({ messages: [...updatedHistory, modelMsg] });
      } else {
        const response = await sendMessageToGemini(
          currentModel, 
          currentMode, 
          currentInput, 
          activeChat.systemInstruction, 
          activeChat.messages,
          currentAttachments
        );
        
        if (response.functionCalls) {
          for (const fc of response.functionCalls) {
            if (fc.name === 'set_session_title' && fc.args.new_title) {
              updateActiveChat({ title: String(fc.args.new_title) });
            }
          }
        }

        const modelMsg: Message = { 
          id: crypto.randomUUID(), 
          role: 'model', 
          content: response.text || (response.attachments ? "Визуализация готова." : ""), 
          attachments: response.attachments,
          timestamp: Date.now() 
        };
        updateActiveChat({ messages: [...updatedHistory, modelMsg] });
      }
    } catch (err: any) {
      console.error("Mirakkarim API Error.");
      const errorStr = JSON.stringify(err).toLowerCase();
      
      if (errorStr.includes("not found") || errorStr.includes("requested entity")) {
        setError("Ошибка аутентификации. Выберите ключ проекта в настройках.");
        if ((window as any).aistudio) await (window as any).aistudio.openSelectKey();
      } else if (errorStr.includes('quota') || errorStr.includes('429')) {
        setError("Лимит запросов исчерпан. Попробуйте позже или обновите тариф.");
        setShowSubscription(true);
      } else {
        setError(`Ошибка: ${err.message || "Сбой системы"}`);
      }
    } finally {
      setIsTyping(false);
      setVideoStatus(null);
    }
  };

  return (
    <div className="flex h-screen bg-[#0b0f1a] overflow-hidden text-slate-100 font-sans selection:bg-blue-500/30">
      {/* Sidebar */}
      <aside className={`${state.isSidebarOpen ? 'w-80' : 'w-0'} bg-[#0d121f] border-r border-slate-800/50 transition-all duration-300 flex flex-col overflow-hidden z-40 relative backdrop-blur-2xl`}>
        <div className="p-8 border-b border-slate-800/50 flex items-center gap-4">
          <div className="w-11 h-11 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center font-black text-2xl shadow-2xl shadow-blue-600/30">M</div>
          <div className="flex flex-col">
            <span className="font-black tracking-tighter text-lg leading-none uppercase">Mirakkarim</span>
            <span className="text-[10px] uppercase font-black text-slate-600 tracking-[0.3em] mt-1">Intelligence OS</span>
          </div>
        </div>
        
        <div className="p-5 space-y-4">
          <button onClick={createNewChat} className="w-full flex items-center justify-center gap-3 bg-blue-600 hover:bg-blue-500 p-4 rounded-2xl font-black shadow-2xl shadow-blue-600/20 transition-all active:scale-95 group">
            <div className="group-hover:rotate-90 transition-transform duration-300"><Icons.Plus /></div>
            НОВЫЙ ЧАТ
          </button>
          
          <div className="relative group">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition-colors">
              <Icons.Search />
            </div>
            <input 
              type="text" 
              placeholder="Поиск чатов..."
              value={chatSearchTerm}
              onChange={(e) => setChatSearchTerm(e.target.value)}
              className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-3 pl-12 pr-4 text-xs font-bold outline-none focus:border-blue-500/50 transition-all placeholder:text-slate-600 text-slate-300"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-4 space-y-2">
          {filteredChats.length > 0 ? filteredChats.map(chat => (
            <div key={chat.id} onClick={() => setState(prev => ({ ...prev, activeChatId: chat.id }))} className={`group flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all ${state.activeChatId === chat.id ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-lg' : 'hover:bg-slate-800/40 text-slate-500'}`}>
              <div className="flex items-center gap-4 overflow-hidden">
                <div className={`p-2 rounded-xl ${state.activeChatId === chat.id ? 'bg-blue-500/20' : 'bg-slate-800'}`}>
                  {chat.model === 'mirakkarim-video-ultra' ? <Icons.Video /> : <Icons.MessageSquare />}
                </div>
                <span className="truncate text-xs font-black uppercase tracking-tight">{chat.title}</span>
              </div>
              <button onClick={(e) => deleteChat(chat.id, e)} className="opacity-0 group-hover:opacity-100 p-2 hover:text-red-500 transition-all"><Icons.Trash /></button>
            </div>
          )) : (
            <div className="px-4 py-8 text-center text-[10px] font-black uppercase text-slate-700 tracking-widest">Чат не найден</div>
          )}
        </div>

        <div className="p-4 space-y-2">
          <button onClick={() => setShowSubscription(true)} className="w-full p-4 rounded-2xl bg-gradient-to-r from-amber-600/20 to-orange-600/20 text-amber-500 border border-amber-500/20 flex items-center gap-4 text-xs font-black transition-all hover:scale-[1.02] active:scale-95">
            <Icons.Alert /> {isSubscribed ? 'MIRAKKARIM PREMIUM' : 'ПОДПИСКА'}
          </button>
          <button onClick={() => setShowSettings(true)} className="w-full p-4 rounded-2xl bg-slate-800/30 border border-slate-700/50 flex items-center gap-4 text-xs font-black text-slate-500 transition-all uppercase tracking-widest hover:bg-slate-800 active:scale-95"><Icons.User /> Профиль</button>
        </div>
      </aside>

      {/* Main View */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#0b0f1a] relative">
        <header className="h-20 border-b border-slate-800/50 flex items-center justify-between px-8 bg-[#0b0f1a]/80 backdrop-blur-3xl sticky top-0 z-30">
          <div className="flex items-center gap-6">
            <button onClick={() => setState(p => ({ ...p, isSidebarOpen: !p.isSidebarOpen }))} className="p-3 hover:bg-slate-800 rounded-2xl text-slate-400 transition-all"><Icons.Menu /></button>
            <div className="flex flex-col">
              <h2 className="text-base font-black truncate max-w-xs md:max-w-md uppercase tracking-tighter">{activeChat ? activeChat.title : 'Mirakkarim Terminal'}</h2>
            </div>
          </div>

          {activeChat && (
            <div className="flex items-center gap-4 sm:gap-6">
              {/* Message Search Toggle */}
              <div className={`flex items-center transition-all duration-300 overflow-hidden ${isMsgSearchOpen ? 'w-48 sm:w-64' : 'w-10'}`}>
                {isMsgSearchOpen ? (
                  <div className="relative flex-1">
                    <input 
                      autoFocus
                      type="text"
                      placeholder="Найти в чате..."
                      value={msgSearchTerm}
                      onChange={(e) => setMsgSearchTerm(e.target.value)}
                      onBlur={() => !msgSearchTerm && setIsMsgSearchOpen(false)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl py-2 pl-4 pr-10 text-[11px] font-bold outline-none focus:border-blue-500/50 transition-all"
                    />
                    <button 
                      onClick={() => {setMsgSearchTerm(''); setIsMsgSearchOpen(false);}}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                    >
                      <Icons.X />
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => setIsMsgSearchOpen(true)}
                    className="p-3 hover:bg-slate-800 rounded-xl text-slate-400 transition-all"
                    title="Поиск сообщений"
                  >
                    <Icons.Search />
                  </button>
                )}
              </div>

              <div className="hidden sm:flex flex-col items-end">
                <span className="text-[9px] uppercase font-black text-slate-600 tracking-widest">Ядро</span>
                <select 
                  value={activeChat.model} 
                  onChange={(e) => updateActiveChat({ model: e.target.value as ModelType })}
                  className="bg-transparent text-[11px] font-black text-blue-400 outline-none cursor-pointer hover:text-blue-300 uppercase text-right"
                >
                  <option value="mirakkarim-3-ultra">Ultra Core</option>
                  <option value="mirakkarim-3-pro">Pro Core</option>
                  <option value="mirakkarim-2.5-lite">Lite Core</option>
                  <option value="mirakkarim-vision-gen">Vision Gen</option>
                  <option value="mirakkarim-video-ultra">Video Ultra</option>
                </select>
              </div>

              <div className="hidden sm:flex flex-col items-end">
                <span className="text-[9px] uppercase font-black text-slate-600 tracking-widest">Протокол</span>
                <select 
                  value={activeChat.mode} 
                  onChange={(e) => updateActiveChat({ mode: e.target.value as GenerationMode })}
                  className="bg-transparent text-[11px] font-black text-orange-400 outline-none cursor-pointer hover:text-orange-300 uppercase text-right"
                >
                  <option value="auto">Auto-Quantum</option>
                  <option value="flash">Flash-Stream</option>
                  <option value="thinking">Deep-Thinking</option>
                  <option value="normal">Stable</option>
                </select>
              </div>
            </div>
          )}
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-6 py-10 relative">
          <div className="max-w-5xl mx-auto">
            {!activeChat ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-40 opacity-20">
                <h1 className="text-4xl font-black tracking-tighter mb-4">MIRAKKARIM INTELLIGENCE</h1>
                <p className="text-sm font-bold tracking-widest text-slate-400 uppercase">Выберите или создайте чат для начала работы</p>
              </div>
            ) : (
              msgSearchTerm ? (
                filteredMessages.length > 0 ? (
                  filteredMessages.map(msg => <ChatMessage key={msg.id} message={msg} />)
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center py-20 opacity-30">
                    <p className="text-sm font-bold tracking-widest text-slate-400 uppercase">Совпадений не найдено</p>
                  </div>
                )
              ) : (
                activeChat.messages.map(msg => <ChatMessage key={msg.id} message={msg} />)
              )
            )}
            
            {videoStatus && (
               <div className="flex flex-col items-start gap-4 ml-6 mb-8 animate-in fade-in duration-500">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-[11px] font-black text-blue-500 uppercase tracking-widest">{videoStatus}</span>
                  </div>
                  <div className="w-full max-w-xs h-1 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 animate-progress origin-left"></div>
                  </div>
               </div>
            )}
            
            {isTyping && !videoStatus && <div className="text-[10px] font-black text-blue-500 animate-pulse ml-6 mb-8 uppercase tracking-widest">Обработка Mirakkarim...</div>}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {activeChat && (
          <div className="p-8 bg-gradient-to-t from-[#0b0f1a] to-transparent">
            <div className="max-w-5xl mx-auto">
              
              {pendingAttachments.length > 0 && (
                <div className="flex flex-wrap gap-3 mb-4 animate-in slide-in-from-bottom-2 duration-300">
                  {pendingAttachments.map((att, idx) => (
                    <div key={idx} className="relative group w-20 h-20 rounded-xl overflow-hidden border border-slate-700 bg-slate-900 shadow-md">
                      <img src={`data:${att.mimeType};base64,${att.data}`} className="w-full h-full object-cover" />
                      <button onClick={() => removePendingAttachment(idx)} className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-lg scale-75 group-hover:scale-100 transition-all"><Icons.X /></button>
                    </div>
                  ))}
                </div>
              )}

              {error && (
                <div className="text-red-500 text-[11px] font-black mb-4 flex items-center justify-between bg-red-500/5 p-4 rounded-2xl border border-red-500/20 animate-shake">
                  <div className="flex items-center gap-3"><Icons.Alert /> {error}</div>
                  <button onClick={() => setError(null)} className="text-slate-500 uppercase text-[9px]">Закрыть</button>
                </div>
              )}

              <div className="relative bg-[#141a29]/80 backdrop-blur-3xl border-2 border-slate-800 rounded-3xl p-3 flex items-end shadow-2xl focus-within:border-blue-500/50 transition-all">
                <button onClick={() => fileInputRef.current?.click()} className="p-4 text-slate-500 hover:text-blue-400 transition-all mb-1"><Icons.Paperclip /></button>
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" multiple accept="image/*" />
                
                <textarea 
                  ref={textareaRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
                  placeholder={activeChat.model === 'mirakkarim-video-ultra' ? "Опишите сцену для генерации видео..." : "Введите запрос для Mirakkarim..."}
                  className="flex-1 bg-transparent border-none outline-none p-4 text-base font-medium resize-none max-h-60 custom-scrollbar"
                  rows={1}
                  onInput={(e) => {
                    const el = e.target as HTMLTextAreaElement;
                    el.style.height = 'auto';
                    el.style.height = `${Math.min(el.scrollHeight, 240)}px`;
                  }}
                />
                <button 
                  onClick={handleSend} 
                  disabled={isTyping || (input.trim() === '' && pendingAttachments.length === 0)} 
                  className="p-4 bg-blue-600 rounded-2xl text-white hover:bg-blue-500 disabled:opacity-20 transition-all mb-1 mr-1 shadow-lg active:scale-95"
                >
                  <Icons.Send />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Subscription */}
        {showSubscription && (
          <div className="fixed inset-0 z-[100] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
            <div className="bg-[#0d121f] border border-slate-800 p-8 rounded-[2.5rem] max-w-4xl w-full relative shadow-2xl">
              <button onClick={() => setShowSubscription(false)} className="absolute top-6 right-6 p-2 text-slate-500 hover:text-white transition-all"><Icons.X /></button>
              <h2 className="text-3xl font-black mb-4 uppercase tracking-tighter">Тарифные планы Mirakkarim</h2>
              <p className="text-slate-400 mb-10 text-sm">Выберите подходящий уровень доступа для раскрытия полного потенциала интеллекта.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="p-8 rounded-[2rem] border border-slate-700 bg-slate-800/20 hover:border-blue-500 transition-all group">
                  <div className="text-xs font-black text-blue-500 mb-2 uppercase tracking-widest">Продвинутый</div>
                  <h3 className="text-2xl font-black mb-4">MIRAKKARIM PRO</h3>
                  <ul className="text-xs text-slate-400 space-y-3 mb-8 font-medium uppercase tracking-tight">
                    <li className="flex items-center gap-2"><Icons.Check /> Доступ к Pro Core</li>
                    <li className="flex items-center gap-2"><Icons.Check /> Безлимитные чаты</li>
                    <li className="flex items-center gap-2"><Icons.Check /> Высокий приоритет</li>
                  </ul>
                  <div className="text-2xl font-black mb-6">990₽ <span className="text-sm text-slate-500">/ МЕС</span></div>
                  <button onClick={() => handleSubscribe('PRO', '990₽')} className="w-full bg-blue-600 py-4 rounded-2xl font-black group-hover:bg-blue-500 transition-all">ВЫБРАТЬ</button>
                </div>

                <div className="p-8 rounded-[2rem] border border-slate-700 bg-slate-800/20 hover:border-indigo-500 transition-all group">
                  <div className="text-xs font-black text-indigo-500 mb-2 uppercase tracking-widest">Максимальный</div>
                  <h3 className="text-2xl font-black mb-4">MIRAKKARIM ULTRA</h3>
                  <ul className="text-xs text-slate-400 space-y-3 mb-8 font-medium uppercase tracking-tight">
                    <li className="flex items-center gap-2"><Icons.Check /> Доступ к Ultra Core</li>
                    <li className="flex items-center gap-2"><Icons.Check /> Генерация видео Veo</li>
                    <li className="flex items-center gap-2"><Icons.Check /> Квантовый приоритет</li>
                  </ul>
                  <div className="text-2xl font-black mb-6">2490₽ <span className="text-sm text-slate-500">/ МЕС</span></div>
                  <button onClick={() => handleSubscribe('ULTRA', '2490₽')} className="w-full bg-indigo-600 py-4 rounded-2xl font-black group-hover:bg-indigo-500 transition-all">ВЫБРАТЬ</button>
                </div>
              </div>

              <div className="text-center">
                <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-[10px] text-slate-600 hover:text-blue-400 uppercase font-bold tracking-widest underline decoration-dotted">Google Billing Documentation & Pricing info</a>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Settings / Profile */}
        {showSettings && (
          <div className="fixed inset-0 z-[100] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
            <div className="bg-[#0d121f] border border-slate-800 p-10 rounded-[2.5rem] max-w-lg w-full relative shadow-2xl">
              <button onClick={() => setShowSettings(false)} className="absolute top-8 right-8 p-2 text-slate-500 hover:text-white transition-all"><Icons.X /></button>
              <h2 className="text-2xl font-black mb-8 uppercase tracking-tighter">Профиль резидента</h2>
              
              <div className="space-y-8">
                <div>
                  <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-3 block">Ваше имя в системе</label>
                  <input 
                    type="text" 
                    value={userName} 
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl p-4 outline-none focus:border-blue-500 transition-all font-bold text-slate-200"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-3 block">Статус доступа</label>
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-tight">{isSubscribed ? 'Premium Access' : 'Basic Access'}</span>
                    <button onClick={() => {setShowSettings(false); setShowSubscription(true);}} className="text-[10px] font-black text-blue-500 uppercase hover:text-blue-400 transition-all">Улучшить</button>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800">
                  <button 
                    onClick={() => {
                      if (confirm("Вы уверены, что хотите удалить все диалоги?")) {
                        setState(p => ({ ...p, chats: [], activeChatId: null }));
                        setShowSettings(false);
                      }
                    }}
                    className="w-full p-4 rounded-2xl bg-red-500/10 text-red-500 border border-red-500/20 text-xs font-black uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all"
                  >
                    Очистить историю чатов
                  </button>
                </div>
              </div>

              <div className="mt-10 text-center opacity-30">
                <div className="text-[9px] font-black uppercase tracking-[0.5em]">Mirakkarim Intelligence OS v2.5</div>
              </div>
            </div>
          </div>
        )}
      </main>
      
      <style>{`
        @keyframes progress { 0% { transform: scaleX(0); } 50% { transform: scaleX(0.7); } 100% { transform: scaleX(1); } }
        .animate-progress { animation: progress 120s infinite ease-in-out; }
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default App;
