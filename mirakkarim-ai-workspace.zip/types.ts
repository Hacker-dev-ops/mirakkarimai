
export type ModelType = 'mirakkarim-3-ultra' | 'mirakkarim-3-pro' | 'mirakkarim-2.5-lite' | 'mirakkarim-vision-gen' | 'mirakkarim-video-ultra';
export type GenerationMode = 'auto' | 'flash' | 'thinking' | 'normal';

export interface Attachment {
  data: string; // base64 or URL for video
  mimeType: string;
  name?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  attachments?: Attachment[];
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  model: ModelType;
  mode: GenerationMode;
  systemInstruction: string;
  messages: Message[];
  createdAt: number;
}

export interface AppState {
  chats: ChatSession[];
  activeChatId: string | null;
  isSidebarOpen: boolean;
}
