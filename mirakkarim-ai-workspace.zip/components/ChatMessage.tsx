
import React, { useState, useEffect, useRef } from 'react';
import { Message, Attachment } from '../types';
import { Icons } from '../constants';

let pyodideInstance: any = null;
let pyodideLoadingPromise: Promise<any> | null = null;

const loadPyodideRuntime = async () => {
  if (pyodideInstance) return pyodideInstance;
  if (pyodideLoadingPromise) return pyodideLoadingPromise;

  pyodideLoadingPromise = (window as any).loadPyodide({
    indexURL: "https://cdn.jsdelivr.net/pyodide/v0.26.1/full/"
  }).then(async (instance: any) => {
    pyodideInstance = instance;
    return instance;
  });

  return pyodideLoadingPromise;
};

const CodeBlock: React.FC<{ code: string; language: string }> = ({ code, language }) => {
  const [copied, setCopied] = useState(false);
  const [output, setOutput] = useState<string[]>([]);
  const [showConsole, setShowConsole] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [runtimeStatus, setRuntimeStatus] = useState<'idle' | 'loading' | 'executing'>('idle');
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const handleCopyCode = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const textToCopy = String(code).trim();
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Copy failed', err);
    }
  };

  const isPython = language.toLowerCase() === 'python' || language.toLowerCase() === 'py';
  const isHtml = language.toLowerCase() === 'html' || language.toLowerCase() === 'xml' || language.toLowerCase() === 'htm';

  const runPythonCode = async () => {
    if (!isPython) return;
    setShowConsole(true);
    setRuntimeStatus('loading');
    setOutput(["[Mirakkarim System] Загрузка ядра..."]);

    try {
      const py = await loadPyodideRuntime();
      setRuntimeStatus('executing');
      
      const safeAppend = (str: string) => {
        setOutput(prev => [...prev, String(str)]);
      };

      py.setStdout({ batched: (str: string) => safeAppend(str) });
      py.setStderr({ batched: (str: string) => safeAppend(`[Error]: ${str}`) });

      await py.runPythonAsync(code);
      setRuntimeStatus('idle');
      setOutput(prev => [...prev, "\n[Выполнено успешно]"]);
    } catch (err: any) {
      let errorMsg = err.message || String(err);
      if (errorMsg.includes('tkinter')) errorMsg = "GUI библиотеки не поддерживаются в браузере.";
      setOutput(prev => [...prev, `\n⚠️ [Ошибка]:\n${errorMsg}`]);
      setRuntimeStatus('idle');
    }
  };

  const toggleFullscreen = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFullscreen(!isFullscreen);
    if (!isFullscreen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  };

  return (
    <div className={`my-6 rounded-2xl overflow-hidden border border-slate-700 bg-slate-950 shadow-2xl relative transition-all duration-300 ${isFullscreen ? 'fixed inset-0 z-[9999] m-0 rounded-none' : ''}`}>
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900/80 border-b border-slate-700 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/40"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/40"></div>
            <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/40"></div>
          </div>
          <span className="text-[10px] font-mono text-slate-500 font-bold uppercase tracking-[0.2em]">{language || 'code'}</span>
        </div>
        
        <div className="flex items-center gap-2">
          {isPython && (
            <button 
              onClick={runPythonCode}
              disabled={runtimeStatus !== 'idle'}
              className="flex items-center gap-2 text-[10px] font-bold px-3 py-1.5 rounded-xl bg-green-500/10 text-green-400 border border-green-500/20 hover:bg-green-500/20 transition-all active:scale-95"
            >
              {runtimeStatus === 'idle' ? <><Icons.Play /> Run</> : <div className="w-3 h-3 border-2 border-green-400 border-t-transparent rounded-full animate-spin"></div>}
            </button>
          )}
          {isHtml && (
            <button 
              onClick={() => setShowPreview(!showPreview)}
              className={`flex items-center gap-2 text-[10px] font-bold px-3 py-1.5 rounded-xl border transition-all active:scale-95 ${showPreview ? 'bg-blue-600 text-white border-blue-500' : 'bg-blue-600/10 text-blue-400 border-blue-500/20 hover:bg-blue-600/20'}`}
            >
              <Icons.Eye /> {showPreview ? 'Source' : 'Preview'}
            </button>
          )}
          <button 
            onClick={handleCopyCode} 
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white border border-slate-700 transition-all active:scale-95"
          >
            {copied ? <Icons.Check /> : <Icons.Copy />}
          </button>
        </div>
      </div>
      
      <div className={`relative ${isFullscreen ? 'h-[calc(100vh-48px)]' : 'min-h-[100px]'}`}>
        {showPreview && isHtml ? (
          <div className="relative group/preview w-full h-full">
            <div className={`w-full bg-white ${isFullscreen ? 'h-full' : 'h-[600px] md:h-[800px] lg:h-[900px]'}`}>
              <iframe 
                ref={iframeRef}
                title="Preview" 
                srcDoc={`<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>body{margin:0;font-family:sans-serif;}</style></head><body>${code}</body></html>`} 
                className="w-full h-full border-none"
                sandbox="allow-scripts allow-modals allow-popups"
              />
            </div>
            <button 
              onClick={toggleFullscreen}
              className="absolute top-4 right-4 p-3 bg-slate-900/80 text-white rounded-2xl border border-white/10 opacity-0 group-hover/preview:opacity-100 transition-all shadow-2xl backdrop-blur-md hover:scale-110 active:scale-90 z-50"
              title={isFullscreen ? "Закрыть" : "На весь экран"}
            >
              {isFullscreen ? <Icons.X /> : (
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="m15 3 6 6M9 21l-6-6M21 3v6h-6M3 21v-6h6M21 3l-6 6M3 21l6-6"/></svg>
              )}
            </button>
          </div>
        ) : (
          <pre className={`p-6 overflow-x-auto custom-scrollbar bg-[#0d1117] ${isFullscreen ? 'h-full' : 'max-h-[800px]'}`}>
            <code className="text-[13px] font-mono text-blue-100/90 block whitespace-pre leading-relaxed">{code.trim()}</code>
          </pre>
        )}
      </div>

      {showConsole && (
        <div className="bg-[#010409] border-t border-slate-800 animate-in slide-in-from-bottom duration-300">
          <div className="px-4 py-2 bg-slate-900/80 text-[10px] text-slate-500 font-bold border-b border-slate-800 flex justify-between items-center backdrop-blur-md">
            <span className="tracking-widest">MIRAKKARIM CONSOLE</span>
            <button onClick={() => setShowConsole(false)} className="hover:text-white transition-colors">HIDE</button>
          </div>
          <div className="p-5 font-mono text-xs max-h-60 overflow-y-auto custom-scrollbar text-green-400/90 leading-relaxed">
            {output.length === 0 ? <div className="animate-pulse">Waiting for execution...</div> : output.map((line, i) => <div key={i} className="mb-1">{line}</div>)}
          </div>
        </div>
      )}
    </div>
  );
};

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isModel = message.role === 'model';
  const parts = message.content.split(/(```[\s\S]*?```)/g);

  const handleDownload = (attachment: Attachment) => {
    const link = document.createElement('a');
    link.href = `data:${attachment.mimeType};base64,${attachment.data}`;
    const extension = attachment.mimeType.split('/')[1] || 'bin';
    link.download = attachment.name || `mirakkarim-generation-${Date.now()}.${extension}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className={`flex w-full mb-10 ${isModel ? 'justify-start' : 'justify-end'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
      <div className={`max-w-[95%] sm:max-w-[88%] p-6 rounded-[2rem] relative transition-all duration-300 shadow-2xl ${
        isModel 
          ? 'bg-slate-800/40 border border-slate-700/50 text-slate-100 rounded-tl-none backdrop-blur-md shadow-slate-950/50' 
          : 'bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-tr-none shadow-blue-900/20'
      }`}>
        <div className="flex items-center gap-2 mb-4 opacity-40 text-[10px] font-black uppercase tracking-[0.2em]">
          {isModel ? (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
              Mirakkarim Intelligence
            </div>
          ) : 'Authorized User'}
        </div>

        {/* Галерея вложений */}
        {message.attachments && message.attachments.length > 0 && (
          <div className="flex flex-wrap gap-4 mb-6">
            {message.attachments.map((att, idx) => (
              <div key={idx} className="group relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl max-w-full">
                {att.mimeType.startsWith('image/') ? (
                  <>
                    <img 
                      src={`data:${att.mimeType};base64,${att.data}`} 
                      alt={att.name || 'attachment'} 
                      className="max-h-[500px] w-auto object-contain bg-slate-900 block" 
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center backdrop-blur-sm">
                      <button 
                        onClick={() => handleDownload(att)}
                        className="p-4 bg-blue-600 text-white rounded-2xl shadow-2xl transform scale-75 group-hover:scale-100 transition-all active:scale-90 flex items-center gap-2 font-black text-xs uppercase tracking-widest"
                      >
                        <Icons.Download /> Скачать
                      </button>
                    </div>
                  </>
                ) : att.mimeType.startsWith('video/') ? (
                  <div className="relative group/video">
                    <video 
                      src={`data:${att.mimeType};base64,${att.data}`} 
                      controls 
                      className="max-h-96 w-full rounded-xl bg-black block"
                    />
                    <button 
                      onClick={() => handleDownload(att)}
                      className="absolute top-4 right-4 p-3 bg-blue-600/90 text-white rounded-xl opacity-0 group-hover/video:opacity-100 transition-all backdrop-blur-md shadow-2xl border border-white/10 hover:bg-blue-500"
                      title="Скачать видео"
                    >
                      <Icons.Download />
                    </button>
                  </div>
                ) : (
                  <div className="bg-slate-900 p-5 flex items-center justify-between gap-6 min-w-[240px]">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-blue-500/20 text-blue-400 rounded-xl">
                        <Icons.Paperclip />
                      </div>
                      <span className="text-xs font-black truncate max-w-[120px] uppercase tracking-tight">{att.name || 'DOC_QUANTUM'}</span>
                    </div>
                    <button 
                      onClick={() => handleDownload(att)}
                      className="p-2 hover:text-blue-400 transition-colors"
                    >
                      <Icons.Download />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="text-sm sm:text-base leading-[1.6] font-medium tracking-tight">
          {parts.map((part, index) => {
            if (part.startsWith('```') && part.endsWith('```')) {
              const match = part.match(/```(\w+)?\n?([\s\S]*?)```/);
              return <CodeBlock key={index} code={match?.[2] || ''} language={match?.[1] || ''} />;
            }
            return <span key={index} className="whitespace-pre-wrap">{part}</span>;
          })}
        </div>
        <div className={`text-[10px] mt-5 opacity-30 font-black ${isModel ? 'text-left' : 'text-right'}`}>
          {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
