
import { GoogleGenAI, GenerateContentResponse, Type, FunctionDeclaration } from "@google/genai";
import { GEMINI_MODEL_MAP } from "../constants";
import { Message, ModelType, GenerationMode, Attachment } from "../types";

export interface GeminiResponse {
  text: string;
  functionCalls?: any[];
  attachments?: Attachment[];
}

const setSessionTitleDeclaration: FunctionDeclaration = {
  name: 'set_session_title',
  parameters: {
    type: Type.OBJECT,
    description: 'Изменить текущее название сессии или чата на более подходящее по запросу пользователя.',
    properties: {
      new_title: {
        type: Type.STRING,
        description: 'Новое краткое и информативное название для чата.',
      },
    },
    required: ['new_title'],
  },
};

export const generateVideoWithMirakkarim = async (
  prompt: string,
  onStatusUpdate?: (status: string) => void
): Promise<Attachment> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  onStatusUpdate?.("Инициализация квантового рендеринга...");
  
  let operation = await ai.models.generateVideos({
    model: GEMINI_MODEL_MAP['mirakkarim-video-ultra'],
    prompt: prompt,
    config: {
      numberOfVideos: 1,
      resolution: '1080p',
      aspectRatio: '16:9'
    }
  });

  onStatusUpdate?.("Синтез кадров и симуляция физики...");

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({operation: operation});
    onStatusUpdate?.("Обработка нейронных связей видеоряда...");
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Не удалось получить ссылку на видео.");

  onStatusUpdate?.("Финальная компиляция видео-потока...");
  
  const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await response.blob();
  
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      resolve({
        data: (reader.result as string).split(',')[1],
        mimeType: 'video/mp4',
        name: 'mirakkarim_generation.mp4'
      });
    };
    reader.readAsDataURL(blob);
  });
};

export const sendMessageToGemini = async (
  modelType: ModelType,
  mode: GenerationMode,
  message: string,
  systemInstruction: string,
  history: Message[],
  newAttachments?: Attachment[]
): Promise<GeminiResponse> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const contents: any[] = history.map(msg => {
    const parts: any[] = [{ text: msg.content }];
    if (msg.attachments) {
      msg.attachments.forEach(att => {
        if (!att.mimeType.startsWith('video/')) {
          parts.push({
            inlineData: {
              data: att.data,
              mimeType: att.mimeType
            }
          });
        }
      });
    }
    return { role: msg.role, parts };
  });

  const currentParts: any[] = [{ text: message }];
  if (newAttachments) {
    newAttachments.forEach(att => {
      currentParts.push({
        inlineData: {
          data: att.data,
          mimeType: att.mimeType
        }
      });
    });
  }

  contents.push({
    role: 'user',
    parts: currentParts
  });

  const modelName = GEMINI_MODEL_MAP[modelType as keyof typeof GEMINI_MODEL_MAP];
  
  const config: any = {
    systemInstruction,
    temperature: mode === 'flash' ? 1.2 : mode === 'thinking' ? 0.7 : 0.9,
    tools: (modelType !== 'mirakkarim-vision-gen' && modelType !== 'mirakkarim-video-ultra') ? [{ functionDeclarations: [setSessionTitleDeclaration] }] : [],
  };

  if (mode === 'thinking' && modelType !== 'mirakkarim-vision-gen' && modelType !== 'mirakkarim-video-ultra') {
    config.thinkingConfig = { thinkingBudget: 16000 };
    config.maxOutputTokens = 25000;
  }

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: modelName,
    contents,
    config
  });

  const responseAttachments: Attachment[] = [];
  let responseText = "";

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        responseAttachments.push({
          data: part.inlineData.data,
          mimeType: part.inlineData.mimeType
        });
      } else if (part.text) {
        responseText += part.text;
      }
    }
  }

  return {
    text: responseText || response.text || "",
    functionCalls: response.functionCalls,
    attachments: responseAttachments.length > 0 ? responseAttachments : undefined
  };
};
